BELDE — EDITABLE GAME SOURCE

Open game/project.godot with the official Godot 4.6.3 standard editor.
For checks and desktop builds, read docs/BUILD.md. Gameplay instructions are in
docs/GAMEPLAY.md. The Chrome editor and native bridge are under extension/ and
native/. The game works without the optional editor.

This source archive contains runtime artwork and authored data inputs. Earlier
concept-board images and the standalone preproduction artbook remain in the
Belde GitHub repository. Downloaded export templates, compilers, import caches,
and generated desktop builds are deliberately excluded from this source ZIP.
